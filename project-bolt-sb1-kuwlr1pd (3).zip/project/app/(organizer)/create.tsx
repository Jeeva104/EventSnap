"use client"

import { useState, useEffect, useRef } from "react"
import { View, Text, TextInput, StyleSheet, ScrollView, TouchableOpacity, Image, Platform, Alert } from "react-native"
import { Picker } from "@react-native-picker/picker"
import DateTimePicker from "@react-native-community/datetimepicker"
import * as ImagePicker from "expo-image-picker"
import { createClient } from "@supabase/supabase-js"
import { useForm, Controller } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"

// Initialize Supabase client - move this outside component to avoid recreating on each render
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://udfromemcidrzxtausgq.supabase.co"
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVkZnJvbWVtY2lkcnp4dGF1c2dxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIyNzg3NDksImV4cCI6MjA1Nzg1NDc0OX0.z4jnqpSPUyzv-iwyhTpuYzXSTegZVeu7PtPU6U52T24"
const supabase = createClient(supabaseUrl, supabaseKey)

// Validation schema
const eventSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  eventDate: z.date().refine((date) => date > new Date(), { message: "Event date must be in the future" }),
  venue: z.string().min(3, { message: "Venue is required" }),
  maxParticipants: z.number().positive({ message: "Maximum participants must be a positive number" }),
  registrationFees: z.number().min(0, { message: "Registration fees must be a positive number or zero" }),
  eventType: z.string().min(1, { message: "Event type is required" }),
  eventStatus: z.string().min(1, { message: "Event status is required" }),
  registrationLink: z.string().url({ message: "Registration link must be a valid URL" }),
})

type EventFormData = z.infer<typeof eventSchema>

export default function CreateEventScreen() {
  // Use useRef to track component mount state
  const isMountedRef = useRef(false)
  const [image, setImage] = useState<string | null>(null)
  const [showDatePicker, setShowDatePicker] = useState(false)
  const [showTimePicker, setShowTimePicker] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [localEventDate, setLocalEventDate] = useState(new Date(Date.now() + 86400000)) // Tomorrow

  // Use useForm hook with zodResolver
  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<EventFormData>({
    resolver: zodResolver(eventSchema),
    defaultValues: {
      title: "",
      description: "",
      eventDate: new Date(Date.now() + 86400000), // Tomorrow
      venue: "",
      maxParticipants: 0,
      registrationFees: 0,
      eventType: "webinar",
      eventStatus: "upcoming",
      registrationLink: "",
    },
  })

  // Watch eventDate safely after component is mounted
  const eventDate = watch("eventDate")

  // Update localEventDate when eventDate changes
  useEffect(() => {
    if (isMountedRef.current) {
      setLocalEventDate(eventDate)
    }
  }, [eventDate])

  // Set component as mounted after initial render
  useEffect(() => {
    isMountedRef.current = true;
    
    return () => {
      isMountedRef.current = false;
    };
  }, []);
  
  const pickImage = async () => {
    // Don't proceed if component isn't mounted
    if (!isMountedRef.current) return;
    
    // Request permissions
    if (Platform.OS !== "web") {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync()
      if (status !== "granted") {
        Alert.alert("Permission needed", "Sorry, we need camera roll permissions to upload images.")
        return
      }
    }

    // Pick the image
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.8,
    })

    if (!result.canceled && isMountedRef.current) {
      setImage(result.assets[0].uri)
    }
  }

  const onSubmit = async (data: EventFormData) => {
    // Don't proceed if component isn't mounted
    if (!isMountedRef.current) return;
    
    try {
      setIsSubmitting(true)

      if (!image) {
        Alert.alert("Error", "Please upload an event banner")
        setIsSubmitting(false)
        return
      }

      // Upload image to Supabase Storage
      const fileExt = image.split(".").pop()
      const fileName = `${Date.now()}.${fileExt}`
      const filePath = `event-banners/${fileName}`

      // For React Native, we need to convert the image URI to a blob
      const response = await fetch(image)
      const blob = await response.blob()

      const { error: uploadError } = await supabase.storage.from("events").upload(filePath, blob)

      if (uploadError) {
        throw new Error("Error uploading image: " + uploadError.message)
      }

      // Get the public URL for the uploaded image
      const { data: publicUrlData } = supabase.storage.from("events").getPublicUrl(filePath)

      const imageUrl = publicUrlData.publicUrl

      // Insert event data into Supabase
      const { error } = await supabase.from("events").insert({
        title: data.title,
        description: data.description,
        event_date: data.eventDate.toISOString(),
        venue: data.venue,
        max_participants: data.maxParticipants,
        registration_fees: data.registrationFees,
        event_type: data.eventType,
        event_status: data.eventStatus,
        registration_link: data.registrationLink,
        banner_image: imageUrl,
      })

      if (error) {
        throw new Error("Error creating event: " + error.message)
      }

      // Check if component is still mounted before updating state
      if (isMountedRef.current) {
        Alert.alert("Success", "Event created successfully!")

        // Reset form
        setValue("title", "")
        setValue("description", "")
        setValue("eventDate", new Date(Date.now() + 86400000)) // Tomorrow
        setValue("venue", "")
        setValue("maxParticipants", 0)
        setValue("registrationFees", 0)
        setValue("eventType", "webinar")
        setValue("eventStatus", "upcoming")
        setValue("registrationLink", "")
        setImage(null)
      }
    } catch (error) {
      if (isMountedRef.current) {
        Alert.alert("Error", error instanceof Error ? error.message : "An unknown error occurred")
      }
    } finally {
      if (isMountedRef.current) {
        setIsSubmitting(false)
      }
    }
  }

  const onDateChange = (event: any, selectedDate?: Date) => {
    // Don't proceed if component isn't mounted
    if (!isMountedRef.current) return;
    
    setShowDatePicker(false)
    if (selectedDate) {
      // Preserve the time from the current eventDate
      const newDate = new Date(selectedDate)
      newDate.setHours(localEventDate.getHours(), localEventDate.getMinutes())
      
      // Update form value
      setValue("eventDate", newDate)
      
      // Update local state for UI rendering
      setLocalEventDate(newDate)
    }
  }

  const onTimeChange = (event: any, selectedTime?: Date) => {
    // Don't proceed if component isn't mounted
    if (!isMountedRef.current) return;
    
    setShowTimePicker(false)
    if (selectedTime) {
      // Preserve the date from the current eventDate
      const newDate = new Date(localEventDate)
      newDate.setHours(selectedTime.getHours(), selectedTime.getMinutes())
      
      // Update form value
      setValue("eventDate", newDate)
      
      // Update local state for UI rendering
      setLocalEventDate(newDate)
    }
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Create New Event</Text>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Event Title *</Text>
        <Controller
          control={control}
          name="title"
          render={({ field: { onChange, value } }) => (
            <TextInput style={styles.input} placeholder="Enter event title" value={value} onChangeText={onChange} />
          )}
        />
        {errors.title && <Text style={styles.errorText}>{errors.title.message}</Text>}
      </View>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Event Description *</Text>
        <Controller
          control={control}
          name="description"
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Enter event description"
              value={value}
              onChangeText={onChange}
              multiline
              numberOfLines={4}
            />
          )}
        />
        {errors.description && <Text style={styles.errorText}>{errors.description.message}</Text>}
      </View>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Event Date and Time *</Text>
        <View style={styles.dateTimeContainer}>
          <TouchableOpacity style={styles.dateTimeButton} onPress={() => isMountedRef.current && setShowDatePicker(true)}>
            <Text>{localEventDate.toLocaleDateString()}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.dateTimeButton} onPress={() => isMountedRef.current && setShowTimePicker(true)}>
            <Text>{localEventDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</Text>
          </TouchableOpacity>
        </View>

        {showDatePicker && 
          <DateTimePicker 
            value={localEventDate} 
            mode="date" 
            display="default" 
            onChange={onDateChange} 
          />
        }

        {showTimePicker && 
          <DateTimePicker 
            value={localEventDate} 
            mode="time" 
            display="default" 
            onChange={onTimeChange} 
          />
        }

        {errors.eventDate && <Text style={styles.errorText}>{errors.eventDate.message}</Text>}
      </View>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Event Venue *</Text>
        <Controller
          control={control}
          name="venue"
          render={({ field: { onChange, value } }) => (
            <TextInput style={styles.input} placeholder="Enter event venue" value={value} onChangeText={onChange} />
          )}
        />
        {errors.venue && <Text style={styles.errorText}>{errors.venue.message}</Text>}
      </View>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Maximum Participants *</Text>
        <Controller
          control={control}
          name="maxParticipants"
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Enter maximum participants"
              value={value.toString()}
              onChangeText={(text) => onChange(parseInt(text) || 0)}
              keyboardType="numeric"
            />
          )}
        />
        {errors.maxParticipants && <Text style={styles.errorText}>{errors.maxParticipants.message}</Text>}
      </View>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Registration Fees (INR) *</Text>
        <Controller
          control={control}
          name="registrationFees"
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Enter registration fees"
              value={value.toString()}
              onChangeText={(text) => onChange(parseInt(text) || 0)}
              keyboardType="numeric"
            />
          )}
        />
        {errors.registrationFees && <Text style={styles.errorText}>{errors.registrationFees.message}</Text>}
      </View>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Event Type *</Text>
        <Controller
          control={control}
          name="eventType"
          render={({ field: { onChange, value } }) => (
            <View style={styles.pickerContainer}>
              <Picker selectedValue={value} onValueChange={onChange} style={styles.picker}>
                <Picker.Item label="Webinar" value="webinar" />
                <Picker.Item label="Hackathon" value="hackathon" />
                <Picker.Item label="Seminar" value="seminar" />
                <Picker.Item label="Workshop" value="workshop" />
                <Picker.Item label="Conference" value="conference" />
                <Picker.Item label="Meetup" value="meetup" />
              </Picker>
            </View>
          )}
        />
        {errors.eventType && <Text style={styles.errorText}>{errors.eventType.message}</Text>}
      </View>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Event Status *</Text>
        <Controller
          control={control}
          name="eventStatus"
          render={({ field: { onChange, value } }) => (
            <View style={styles.pickerContainer}>
              <Picker selectedValue={value} onValueChange={onChange} style={styles.picker}>
                <Picker.Item label="Upcoming" value="upcoming" />
                <Picker.Item label="Active" value="active" />
              </Picker>
            </View>
          )}
        />
        {errors.eventStatus && <Text style={styles.errorText}>{errors.eventStatus.message}</Text>}
      </View>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Registration Link *</Text>
        <Controller
          control={control}
          name="registrationLink"
          render={({ field: { onChange, value } }) => (
            <TextInput
              style={styles.input}
              placeholder="Enter registration link"
              value={value}
              onChangeText={onChange}
              keyboardType="url"
            />
          )}
        />
        {errors.registrationLink && <Text style={styles.errorText}>{errors.registrationLink.message}</Text>}
      </View>

      <View style={styles.formGroup}>
        <Text style={styles.label}>Event Banner *</Text>
        <TouchableOpacity style={styles.imageUploadButton} onPress={pickImage}>
          <Text style={styles.imageUploadButtonText}>Upload Image</Text>
        </TouchableOpacity>
        {image && <Image source={{ uri: image }} style={styles.previewImage} />}
        {!image && <Text style={styles.errorText}>Event banner is required</Text>}
      </View>

      <TouchableOpacity
        style={[styles.submitButton, isSubmitting && styles.disabledButton]}
        onPress={handleSubmit(onSubmit)}
        disabled={isSubmitting}
      >
        <Text style={styles.submitButtonText}>{isSubmitting ? "Creating Event..." : "Create Event"}</Text>
      </TouchableOpacity>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "#f5f5f5",
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  formGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: "500",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: "#fff",
  },
  textArea: {
    height: 100,
    textAlignVertical: "top",
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    backgroundColor: "#fff",
  },
  picker: {
    height: 50,
  },
  dateTimeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  dateTimeButton: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 12,
    flex: 0.48,
    backgroundColor: "#fff",
    alignItems: "center",
  },
  imageUploadButton: {
    backgroundColor: "#e0e0e0",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 10,
  },
  imageUploadButtonText: {
    fontSize: 16,
    color: "#333",
  },
  previewImage: {
    width: "100%",
    height: 200,
    borderRadius: 8,
    marginTop: 10,
  },
  submitButton: {
    backgroundColor: "#4CAF50",
    padding: 16,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 20,
    marginBottom: 40,
  },
  disabledButton: {
    backgroundColor: "#a5d6a7",
  },
  submitButtonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  errorText: {
    color: "red",
    fontSize: 14,
    marginTop: 5,
  },
})