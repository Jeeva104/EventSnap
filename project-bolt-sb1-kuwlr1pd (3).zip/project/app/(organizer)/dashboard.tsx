import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Users, Calendar, TrendingUp, Clock, CirclePlus as PlusCircle } from 'lucide-react-native';
import { supabase } from '../../lib/supabase';
import { router } from 'expo-router';

export default function OrganizerDashboard() {
  const [stats, setStats] = useState([
    { icon: Calendar, label: 'Total Events', value: '0' },
    { icon: Users, label: 'Total Participants', value: '0' },
    { icon: TrendingUp, label: 'Active Events', value: '0' },
    { icon: Clock, label: 'Upcoming Events', value: '0' },
  ]);
  const [recentEvents, setRecentEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Fetch events organized by the current user
      const { data: events, error } = await supabase
        .from('events')
        .select('*')
        .eq('organizer_id', user.id)
        .order('date', { ascending: true });

      if (error) throw error;

      // Format events for display
      const formattedEvents = events.map(event => ({
        id: event.id,
        title: event.title,
        date: new Date(event.date).toLocaleDateString('en-US', { 
          month: 'short', 
          day: 'numeric', 
          year: 'numeric' 
        }),
        participants: event.participants_count || 0,
        status: getEventStatus(event.date),
      }));

      setRecentEvents(formattedEvents);

      // Update stats
      updateStats(events);
    } catch (error) {
      console.error('Error fetching events:', error);
      Alert.alert('Error', 'Failed to load events');
    } finally {
      setLoading(false);
    }
  };

  const getEventStatus = (dateString) => {
    const eventDate = new Date(dateString);
    const now = new Date();
    return eventDate > now ? 'upcoming' : 'active';
  };

  const updateStats = (events) => {
    const now = new Date();
    const totalEvents = events.length;
    const totalParticipants = events.reduce((sum, event) => sum + (event.participants_count || 0), 0);
    const activeEvents = events.filter(event => new Date(event.date) <= now).length;
    const upcomingEvents = events.filter(event => new Date(event.date) > now).length;

    setStats([
      { icon: Calendar, label: 'Total Events', value: totalEvents.toString() },
      { icon: Users, label: 'Total Participants', value: totalParticipants.toString() },
      { icon: TrendingUp, label: 'Active Events', value: activeEvents.toString() },
      { icon: Clock, label: 'Upcoming Events', value: upcomingEvents.toString() },
    ]);
  };

  const handleCreateEvent = () => {
    router.push('/events/create');
  };

  const handleViewCalendar = () => {
    // Implement calendar view navigation
    Alert.alert('Info', 'Calendar view will be implemented soon');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.greeting}>Welcome back, Organizer! 👋</Text>
          <Text style={styles.subtitle}>Here's an overview of your events</Text>
        </View>

        <View style={styles.statsGrid}>
          {stats.map((stat, index) => (
            <View key={index} style={styles.statCard}>
              <View style={styles.statIconContainer}>
                <stat.icon size={24} color="#6366f1" />
              </View>
              <Text style={styles.statValue}>{stat.value}</Text>
              <Text style={styles.statLabel}>{stat.label}</Text>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Events</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllButton}>See All</Text>
            </TouchableOpacity>
          </View>

          {loading ? (
            <Text style={styles.loadingText}>Loading events...</Text>
          ) : recentEvents.length === 0 ? (
            <Text style={styles.noEventsText}>No events found. Create your first event!</Text>
          ) : (
            recentEvents.map((event) => (
              <TouchableOpacity 
                key={event.id} 
                style={styles.eventCard}
                onPress={() => router.push(`/events/${event.id}`)}
              >
                <View style={styles.eventHeader}>
                  <Text style={styles.eventTitle}>{event.title}</Text>
                  <View
                    style={[
                      styles.statusBadge,
                      event.status === 'active'
                        ? styles.activeBadge
                        : styles.upcomingBadge,
                    ]}
                  >
                    <Text
                      style={[
                        styles.statusText,
                        event.status === 'active'
                          ? styles.activeText
                          : styles.upcomingText,
                      ]}
                    >
                      {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                    </Text>
                  </View>
                </View>
                <View style={styles.eventDetails}>
                  <View style={styles.detailRow}>
                    <Calendar size={16} color="#6b7280" />
                    <Text style={styles.detailText}>{event.date}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Users size={16} color="#6b7280" />
                    <Text style={styles.detailText}>{event.participants} participants</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))
          )}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
          </View>
          <View style={styles.actionButtons}>
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleCreateEvent}
            >
              <PlusCircle size={24} color="#6366f1" />
              <Text style={styles.actionButtonText}>Create Event</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.actionButton}
              onPress={handleViewCalendar}
            >
              <Calendar size={24} color="#6366f1" />
              <Text style={styles.actionButtonText}>View Calendar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: '#ffffff',
  },
  greeting: {
    fontSize: 24,
    fontFamily: 'Inter_600SemiBold',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 10,
    gap: 10,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statIconContainer: {
    width: 48,
    height: 48,
    backgroundColor: '#ede9fe',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    color: '#111827',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
    textAlign: 'center',
  },
  section: {
    marginTop: 20,
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter_600SemiBold',
    color: '#111827',
  },
  seeAllButton: {
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    color: '#6366f1',
  },
  eventCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  eventTitle: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
    color: '#111827',
    marginRight: 8,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  activeBadge: {
    backgroundColor: '#dcfce7',
  },
  upcomingBadge: {
    backgroundColor: '#dbeafe',
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },
  activeText: {
    color: '#059669',
  },
  upcomingText: {
    color: '#3b82f6',
  },
  eventDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  actionButtonText: {
    marginTop: 8,
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    color: '#6366f1',
  },
  loadingText: {
    textAlign: 'center',
    padding: 16,
    color: '#6b7280',
  },
  noEventsText: {
    textAlign: 'center',
    padding: 16,
    color: '#6b7280',
    fontStyle: 'italic',
  },
});