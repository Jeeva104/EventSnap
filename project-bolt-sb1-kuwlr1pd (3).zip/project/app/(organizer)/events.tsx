import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, ActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Calendar, MapPin, Clock } from 'lucide-react-native';
import { supabase } from './supabase'; // Import the Supabase client
import { router } from 'expo-router'; // Import the router

export default function MyEventsScreen() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch events created by the authenticated user
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          throw new Error('Not authenticated');
        }

        // Fetch events created by the user
        const { data: eventsData, error: eventsError } = await supabase
          .from('events')
          .select('*')
          .eq('organizer_id', user.id);

        if (eventsError) throw eventsError;

        // Fetch booking counts for each event
        const eventsWithBookings = await Promise.all(
          eventsData.map(async (event) => {
            const { count, error: bookingsError } = await supabase
              .from('bookings')
              .select('*', { count: 'exact' })
              .eq('event_id', event.id);

            if (bookingsError) throw bookingsError;

            return {
              ...event,
              bookingCount: count || 0,
              isFull: event.max_participants ? count >= event.max_participants : false,
            };
          })
        );

        setEvents(eventsWithBookings);
      } catch (error) {
        console.error('Error fetching events:', error);
        Alert.alert('Error', 'Failed to fetch events. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  const handleCloseEvent = async (eventId) => {
    try {
      const { error } = await supabase
        .from('events')
        .update({ status: 'closed' })
        .eq('id', eventId);

      if (error) throw error;

      // Update the local state to reflect the closed event
      setEvents((prevEvents) =>
        prevEvents.map((event) =>
          event.id === eventId ? { ...event, status: 'closed' } : event
        )
      );

      Alert.alert('Success', 'Event has been closed.');
    } catch (error) {
      console.error('Error closing event:', error);
      Alert.alert('Error', 'Failed to close the event. Please try again.');
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color="#6366f1" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Events</Text>
      </View>

      <ScrollView style={styles.content}>
        {events.map((event) => (
          <TouchableOpacity key={event.id} style={styles.eventCard}>
            <Image source={{ uri: event.image || 'https://via.placeholder.com/400' }} style={styles.eventImage} />
            <View style={styles.eventContent}>
              <View style={styles.eventHeader}>
                <Text style={styles.eventTitle}>{event.title}</Text>
                <View style={[styles.statusBadge, styles[`status_${event.status}`]]}>
                  <Text style={styles.statusText}>
                    {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                  </Text>
                </View>
              </View>

              <View style={styles.eventDetails}>
                <View style={styles.detailRow}>
                  <Calendar size={16} color="#6b7280" />
                  <Text style={styles.detailText}>{new Date(event.date).toLocaleDateString()}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Clock size={16} color="#6b7280" />
                  <Text style={styles.detailText}>{new Date(event.date).toLocaleTimeString()}</Text>
                </View>
                <View style={styles.detailRow}>
                  <MapPin size={16} color="#6b7280" />
                  <Text style={styles.detailText}>{event.location}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailText}>
                    {event.bookingCount} / {event.max_participants || '∞'} attendees
                  </Text>
                </View>
              </View>

              {event.status === 'upcoming' && (
                <View style={styles.actions}>
                  <TouchableOpacity
                    style={styles.viewDetailsButton}
                    onPress={() => router.push({ pathname: '/EventDetails', params: { eventId: event.id } })}
                  >
                    <Text style={styles.viewDetailsText}>View Details</Text>
                  </TouchableOpacity>

                  {event.isFull && (
                    <TouchableOpacity
                      style={styles.closeEventButton}
                      onPress={() => handleCloseEvent(event.id)}
                    >
                      <Text style={styles.closeEventText}>Close Event</Text>
                    </TouchableOpacity>
                  )}
                </View>
              )}
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  header: {
    padding: 20,
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter_600SemiBold',
    color: '#111827',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  eventCard: {
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  eventImage: {
    width: '100%',
    height: 160,
  },
  eventContent: {
    padding: 16,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  eventTitle: {
    flex: 1,
    fontSize: 18,
    fontFamily: 'Inter_500Medium',
    color: '#111827',
    marginRight: 8,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  status_upcoming: {
    backgroundColor: '#dbeafe',
  },
  status_registered: {
    backgroundColor: '#dcfce7',
  },
  status_completed: {
    backgroundColor: '#f3f4f6',
  },
  status_closed: {
    backgroundColor: '#f3f4f6',
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },
  eventDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  actions: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 16,
  },
  viewDetailsButton: {
    backgroundColor: '#6366f1',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
  },
  viewDetailsText: {
    color: '#ffffff',
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
  },
  closeEventButton: {
    backgroundColor: '#ef4444',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
  },
  closeEventText: {
    color: '#ffffff',
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
  },
});