// supabase.js
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://udfromemcidrzxtausgq.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVkZnJvbWVtY2lkcnp4dGF1c2dxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIyNzg3NDksImV4cCI6MjA1Nzg1NDc0OX0.z4jnqpSPUyzv-iwyhTpuYzXSTegZVeu7PtPU6U52T24';
export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

export async function createEvent(eventData: any) {
  const { data, error } = await supabase.from("events").insert(eventData).select()

  if (error) throw error
  return data
}

export async function getEvents(filters = {}) {
  let query = supabase.from("events").select("*")

  // Apply filters if any
  if (filters) {
    Object.entries(filters).forEach(([key, value]) => {
      query = query.eq(key, value)
    })
  }

  const { data, error } = await query.order("event_date", { ascending: true })

  if (error) throw error
  return data
}

export async function getEventById(id: number) {
  const { data, error } = await supabase.from("events").select("*").eq("id", id).single()

  if (error) throw error
  return data
}

export async function updateEvent(id: number, updates: any) {
  const { data, error } = await supabase.from("events").update(updates).eq("id", id).select()

  if (error) throw error
  return data
}

export async function deleteEvent(id: number) {
  const { error } = await supabase.from("events").delete().eq("id", id)

  if (error) throw error
  return true
}

// Participant related functions
export async function registerParticipant(participantData: any) {
  const { data, error } = await supabase.from("participants").insert(participantData).select()

  if (error) throw error
  return data
}

export async function getEventParticipants(eventId: number) {
  const { data, error } = await supabase.from("participants").select("*").eq("event_id", eventId)

  if (error) throw error
  return data
}

export async function updateParticipantStatus(id: number, status: string) {
  const { data, error } = await supabase.from("participants").update({ payment_status: status }).eq("id", id).select()

  if (error) throw error
  return data
}

