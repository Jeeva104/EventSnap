import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Calendar, MapPin, Users } from 'lucide-react-native';
import { format } from 'date-fns';
import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabaseUrl = 'https://udfromemcidrzxtausgq.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVkZnJvbWVtY2lkcnp4dGF1c2dxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIyNzg3NDksImV4cCI6MjA1Nzg1NDc0OX0.z4jnqpSPUyzv-iwyhTpuYzXSTegZVeu7PtPU6U52T24';
const supabase = createClient(supabaseUrl, supabaseKey);

export default function HomeScreen() {
  const [featuredEvents, setFeaturedEvents] = useState([]);
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      // First, let's fetch the table structure to see the actual column names
      const { data: tableInfo, error: tableError } = await supabase
        .from('events')
        .select('*')
        .limit(1);
      
      if (tableError) {
        console.error('Error fetching table structure:', tableError);
        setError('Could not fetch events table structure');
        setLoading(false);
        return;
      }

      console.log('Table structure:', tableInfo);
      
      // Assuming the table exists but has different column names
      // Let's fetch all events without ordering by date first
      const { data, error } = await supabase
        .from('events')
        .select('*');
      
      if (error) {
        console.error('Error fetching events:', error);
        setError('Could not fetch events data');
        setLoading(false);
        return;
      }
      
      console.log('Fetched events:', data);
      
      // Process the data based on the actual structure
      // We'll determine the date field dynamically
      const dateField = determineFieldName(data[0], ['date', 'event_date', 'created_at', 'timestamp']);
      const titleField = determineFieldName(data[0], ['title', 'name', 'event_title', 'event_name']);
      const locationField = determineFieldName(data[0], ['location', 'place', 'venue']);
      const attendeesField = determineFieldName(data[0], ['attendees', 'participants', 'attendance']);
      const imageField = determineFieldName(data[0], ['image', 'image_url', 'photo', 'thumbnail']);
      const featuredField = determineFieldName(data[0], ['featured', 'is_featured']);
      
      // Map the data to our expected structure
      const processedData = data.map(event => ({
        id: event.id,
        title: event[titleField] || 'Unnamed Event',
        date: new Date(event[dateField] || new Date()),
        location: event[locationField] || 'Unknown Location',
        attendees: event[attendeesField] || 0,
        image: event[imageField] || 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=800',
        featured: event[featuredField] || false
      }));
      
      const currentDate = new Date();
      
      // Filter for featured events
      const featured = processedData.filter(event => event.featured);
      
      // Filter for upcoming events (date is in the future and not featured)
      const upcoming = processedData.filter(
        event => 
          event.date >= currentDate && 
          !event.featured
      );
      
      setFeaturedEvents(featured.slice(0, 2)); // Limit to 2 featured events
      setUpcomingEvents(upcoming.slice(0, 2)); // Limit to 2 upcoming events
      setLoading(false);
    } catch (error) {
      console.error('Error in fetchEvents:', error);
      setError('An unexpected error occurred');
      setLoading(false);
    }
  };

  // Helper function to determine the actual field name from possible options
  const determineFieldName = (obj, possibleNames) => {
    if (!obj) return null;
    for (const name of possibleNames) {
      if (obj.hasOwnProperty(name)) {
        return name;
      }
    }
    return null;
  };

  // Show loading state
  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading events...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // Show error state
  if (error) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorTitle}>Error</Text>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={fetchEvents}>
            <Text style={styles.retryButtonText}>Retry</Text>
          </TouchableOpacity>
          
          {/* Fallback to static data if there's an error */}
          <Text style={styles.fallbackText}>Showing sample events instead:</Text>
        </View>
        
        {/* Render the original static data as fallback */}
        <ScrollView style={styles.scrollView}>
          <View style={styles.header}>
            <Text style={styles.greeting}>Hello, Student! 👋</Text>
            <Text style={styles.subtitle}>Discover amazing events happening around you</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Featured Events</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.featuredScroll}>
              {FEATURED_EVENTS.map((event) => (
                <TouchableOpacity key={event.id} style={styles.featuredCard}>
                  <Image source={{ uri: event.image }} style={styles.featuredImage} />
                  <View style={styles.featuredContent}>
                    <Text style={styles.eventTitle}>{event.title}</Text>
                    <View style={styles.eventDetails}>
                      <View style={styles.detailRow}>
                        <Calendar size={16} color="#6b7280" />
                        <Text style={styles.detailText}>{format(event.date, 'MMM d, yyyy')}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <MapPin size={16} color="#6b7280" />
                        <Text style={styles.detailText}>{event.location}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Users size={16} color="#6b7280" />
                        <Text style={styles.detailText}>{event.attendees} attendees</Text>
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Upcoming Events</Text>
            {UPCOMING_EVENTS.map((event) => (
              <TouchableOpacity key={event.id} style={styles.upcomingCard}>
                <Image source={{ uri: event.image }} style={styles.upcomingImage} />
                <View style={styles.upcomingContent}>
                  <Text style={styles.eventTitle}>{event.title}</Text>
                  <View style={styles.eventDetails}>
                    <View style={styles.detailRow}>
                      <Calendar size={16} color="#6b7280" />
                      <Text style={styles.detailText}>{format(event.date, 'MMM d, yyyy')}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <MapPin size={16} color="#6b7280" />
                      <Text style={styles.detailText}>{event.location}</Text>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.greeting}>Hello, Student! 👋</Text>
          <Text style={styles.subtitle}>Discover amazing events happening around you</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Featured Events</Text>
          {featuredEvents.length > 0 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.featuredScroll}>
              {featuredEvents.map((event) => (
                <TouchableOpacity key={event.id} style={styles.featuredCard}>
                  <Image source={{ uri: event.image }} style={styles.featuredImage} />
                  <View style={styles.featuredContent}>
                    <Text style={styles.eventTitle}>{event.title}</Text>
                    <View style={styles.eventDetails}>
                      <View style={styles.detailRow}>
                        <Calendar size={16} color="#6b7280" />
                        <Text style={styles.detailText}>{format(event.date, 'MMM d, yyyy')}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <MapPin size={16} color="#6b7280" />
                        <Text style={styles.detailText}>{event.location}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Users size={16} color="#6b7280" />
                        <Text style={styles.detailText}>{event.attendees} attendees</Text>
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          ) : (
            <Text style={styles.emptyText}>No featured events at this time</Text>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Upcoming Events</Text>
          {upcomingEvents.length > 0 ? (
            upcomingEvents.map((event) => (
              <TouchableOpacity key={event.id} style={styles.upcomingCard}>
                <Image source={{ uri: event.image }} style={styles.upcomingImage} />
                <View style={styles.upcomingContent}>
                  <Text style={styles.eventTitle}>{event.title}</Text>
                  <View style={styles.eventDetails}>
                    <View style={styles.detailRow}>
                      <Calendar size={16} color="#6b7280" />
                      <Text style={styles.detailText}>{format(event.date, 'MMM d, yyyy')}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <MapPin size={16} color="#6b7280" />
                      <Text style={styles.detailText}>{event.location}</Text>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))
          ) : (
            <Text style={styles.emptyText}>No upcoming events at this time</Text>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// Fallback static data
const FEATURED_EVENTS = [
  {
    id: 1,
    title: 'React Native Hackathon 2024',
    date: new Date('2024-03-15'),
    location: 'Engineering Building, Block A',
    attendees: 150,
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 2,
    title: 'AI & Machine Learning Workshop',
    date: new Date('2024-03-20'),
    location: 'Computer Science Department',
    attendees: 75,
    image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=800',
  },
];

const UPCOMING_EVENTS = [
  {
    id: 3,
    title: 'Web Development Seminar',
    date: new Date('2024-03-25'),
    location: 'Virtual Event',
    attendees: 200,
    image: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 4,
    title: 'Cybersecurity Workshop',
    date: new Date('2024-03-28'),
    location: 'IT Lab Complex',
    attendees: 50,
    image: 'https://images.unsplash.com/photo-1550177997-598e3c0dbaf3?auto=format&fit=crop&q=80&w=800',
  },
];

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: '#ffffff',
  },
  greeting: {
    fontSize: 24,
    fontFamily: 'Inter_600SemiBold',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter_600SemiBold',
    color: '#111827',
    marginBottom: 16,
  },
  featuredScroll: {
    marginHorizontal: -20,
    paddingHorizontal: 20,
  },
  featuredCard: {
    width: 300,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  featuredImage: {
    width: '100%',
    height: 160,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  featuredContent: {
    padding: 16,
  },
  upcomingCard: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  upcomingImage: {
    width: 100,
    height: 100,
    borderTopLeftRadius: 12,
    borderBottomLeftRadius: 12,
  },
  upcomingContent: {
    flex: 1,
    padding: 12,
  },
  eventTitle: {
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
    color: '#111827',
    marginBottom: 8,
  },
  eventDetails: {
    gap: 4,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
    color: '#6b7280',
  },
  emptyText: {
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
    textAlign: 'center',
    marginVertical: 20,
  },
  errorContainer: {
    padding: 20,
    alignItems: 'center',
  },
  errorTitle: {
    fontSize: 20,
    fontFamily: 'Inter_600SemiBold',
    color: '#ef4444',
    marginBottom: 8,
  },
  errorText: {
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
    marginBottom: 16,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 6,
    marginBottom: 20,
  },
  retryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
  },
  fallbackText: {
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
    color: '#6b7280',
    marginBottom: 10,
  },
});