import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Settings, Bell, BookOpen, Award, LogOut } from 'lucide-react-native';
import { useAuth } from '@/hooks/useAuth';
import { useProfile } from '@/hooks/useProfile';

const PROFILE_MENU = [
  {
    icon: Settings,
    title: 'Settings',
    subtitle: 'App preferences and account settings',
  },
  {
    icon: Bell,
    title: 'Notifications',
    subtitle: 'Manage your notification preferences',
  },
  {
    icon: BookOpen,
    title: 'My Certificates',
    subtitle: 'View your earned certificates',
  },
  {
    icon: Award,
    title: 'Achievements',
    subtitle: 'Your badges and accomplishments',
  },
];

export default function ProfileScreen() {
  const { user, userType, signOut } = useAuth();
  const { stats, loading } = useProfile();

  const handleLogout = async () => {
    const { error } = await signOut();
    if (!error) {
      router.replace('/login');
    }
  };

  if (!user) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Please log in to view your profile</Text>
          <TouchableOpacity 
            style={styles.loginButton}
            onPress={() => router.replace('/login')}
          >
            <Text style={styles.loginButtonText}>Go to Login</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <View style={styles.profileSection}>
            <Image
              source={{ uri: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200&h=200' }}
              style={styles.profileImage}
            />
            <View style={styles.profileInfo}>
              <Text style={styles.name}>{user.full_name}</Text>
              <Text style={styles.email}>{user.email}</Text>
              <Text style={styles.institutionText}>{user.college_name}</Text>
              {userType === 'student' ? (
                <Text style={styles.yearText}>Year {user.year_of_study}</Text>
              ) : (
                <>
                  <Text style={styles.departmentText}>{user.department}</Text>
                  {user.event_types && (
                    <Text style={styles.eventTypesText}>
                      Specializes in: {user.event_types}
                    </Text>
                  )}
                </>
              )}
              <TouchableOpacity style={styles.editButton}>
                <Text style={styles.editButtonText}>Edit Profile</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.statsContainer}>
            {loading ? (
              <ActivityIndicator color="#6366f1" />
            ) : (
              <>
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>{stats.eventsAttended}</Text>
                  <Text style={styles.statLabel}>
                    {userType === 'student' ? 'Events Attended' : 'Events Organized'}
                  </Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>{stats.certificatesCount}</Text>
                  <Text style={styles.statLabel}>Certificates</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>{stats.upcomingEvents}</Text>
                  <Text style={styles.statLabel}>Upcoming Events</Text>
                </View>
              </>
            )}
          </View>
        </View>

        <View style={styles.menuSection}>
          {PROFILE_MENU.map((item, index) => (
            <TouchableOpacity key={index} style={styles.menuItem}>
              <View style={styles.menuIcon}>
                <item.icon size={24} color="#6366f1" />
              </View>
              <View style={styles.menuText}>
                <Text style={styles.menuTitle}>{item.title}</Text>
                <Text style={styles.menuSubtitle}>{item.subtitle}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <LogOut size={20} color="#ef4444" />
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
    color: '#6b7280',
    marginBottom: 16,
  },
  loginButton: {
    backgroundColor: '#6366f1',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  loginButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    backgroundColor: '#ffffff',
    padding: 20,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  name: {
    fontSize: 24,
    fontFamily: 'Inter_600SemiBold',
    color: '#111827',
    marginBottom: 4,
  },
  email: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
    marginBottom: 4,
  },
  institutionText: {
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    color: '#4b5563',
    marginBottom: 4,
  },
  yearText: {
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    color: '#6366f1',
    marginBottom: 12,
  },
  departmentText: {
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    color: '#6366f1',
    marginBottom: 4,
  },
  eventTypesText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
    marginBottom: 12,
  },
  editButton: {
    backgroundColor: '#6366f1',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  editButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 16,
    minHeight: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontFamily: 'Inter_600SemiBold',
    color: '#6366f1',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
    textAlign: 'center',
  },
  statDivider: {
    width: 1,
    backgroundColor: '#e5e7eb',
    marginHorizontal: 12,
  },
  menuSection: {
    backgroundColor: '#ffffff',
    marginTop: 20,
    paddingVertical: 8,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  menuIcon: {
    width: 40,
    height: 40,
    backgroundColor: '#ede9fe',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  menuText: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
    color: '#111827',
    marginBottom: 2,
  },
  menuSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fee2e2',
    marginTop: 20,
    marginHorizontal: 20,
    marginBottom: 32,
    padding: 16,
    borderRadius: 12,
  },
  logoutText: {
    marginLeft: 8,
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
    color: '#ef4444',
  },
});