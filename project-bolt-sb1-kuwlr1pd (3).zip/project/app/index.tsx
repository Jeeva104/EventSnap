import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Calendar, MapPin, Users } from 'lucide-react-native';
import { format } from 'date-fns';
import { Link, router } from 'expo-router';

const FEATURED_EVENTS = [
  {
    id: 1,
    title: 'React Native Hackathon 2024',
    date: new Date('2024-03-15'),
    location: 'Engineering Building, Block A',
    attendees: 150,
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 2,
    title: 'AI & Machine Learning Workshop',
    date: new Date('2024-03-20'),
    location: 'Computer Science Department',
    attendees: 75,
    image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=800',
  },
];

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <Text style={styles.title}>EventSnap</Text>
          <Text style={styles.subtitle}>Your College Event Hub</Text>
        </View>

        <View style={styles.authButtons}>
          <Link href="/register" asChild>
            <TouchableOpacity style={styles.registerButton}>
              <Text style={styles.registerButtonText}>Register</Text>
            </TouchableOpacity>
          </Link>
          <TouchableOpacity 
            style={styles.loginButton}
            onPress={() => router.push('/login')}
          >
            <Text style={styles.loginButtonText}>Login</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Featured Events</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.featuredScroll}>
            {FEATURED_EVENTS.map((event) => (
              <TouchableOpacity key={event.id} style={styles.featuredCard}>
                <Image source={{ uri: event.image }} style={styles.featuredImage} />
                <View style={styles.featuredContent}>
                  <Text style={styles.eventTitle}>{event.title}</Text>
                  <View style={styles.eventDetails}>
                    <View style={styles.detailRow}>
                      <Calendar size={16} color="#6b7280" />
                      <Text style={styles.detailText}>{format(event.date, 'MMM d, yyyy')}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <MapPin size={16} color="#6b7280" />
                      <Text style={styles.detailText}>{event.location}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Users size={16} color="#6b7280" />
                      <Text style={styles.detailText}>{event.attendees} attendees</Text>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.infoSection}>
          <Text style={styles.infoTitle}>Why EventSnap?</Text>
          <View style={styles.infoGrid}>
            <View style={styles.infoCard}>
              <Text style={styles.infoCardTitle}>Discover Events</Text>
              <Text style={styles.infoCardText}>Find and participate in exciting college events</Text>
            </View>
            <View style={styles.infoCard}>
              <Text style={styles.infoCardTitle}>Organize Events</Text>
              <Text style={styles.infoCardText}>Create and manage your own events</Text>
            </View>
            <View style={styles.infoCard}>
              <Text style={styles.infoCardTitle}>Track Progress</Text>
              <Text style={styles.infoCardText}>Keep track of your event participation</Text>
            </View>
            <View style={styles.infoCard}>
              <Text style={styles.infoCardTitle}>Get Certified</Text>
              <Text style={styles.infoCardText}>Earn certificates for your achievements</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    padding: 20,
    backgroundColor: '#ffffff',
    alignItems: 'center',
  },
  title: {
    fontSize: 32,
    fontFamily: 'Inter_700Bold',
    color: '#6366f1',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 18,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  authButtons: {
    flexDirection: 'row',
    gap: 12,
    padding: 20,
    backgroundColor: '#ffffff',
  },
  registerButton: {
    flex: 1,
    backgroundColor: '#6366f1',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  registerButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
  loginButton: {
    flex: 1,
    backgroundColor: '#ffffff',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#6366f1',
  },
  loginButtonText: {
    color: '#6366f1',
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
  section: {
    marginTop: 24,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter_600SemiBold',
    color: '#111827',
    marginBottom: 16,
  },
  featuredScroll: {
    marginHorizontal: -20,
    paddingHorizontal: 20,
  },
  featuredCard: {
    width: 300,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  featuredImage: {
    width: '100%',
    height: 160,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  featuredContent: {
    padding: 16,
  },
  eventTitle: {
    fontSize: 16,
    fontFamily: 'Inter_500Medium',
    color: '#111827',
    marginBottom: 8,
  },
  eventDetails: {
    gap: 4,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  infoSection: {
    marginTop: 32,
    padding: 20,
    backgroundColor: '#ffffff',
  },
  infoTitle: {
    fontSize: 24,
    fontFamily: 'Inter_600SemiBold',
    color: '#111827',
    marginBottom: 20,
    textAlign: 'center',
  },
  infoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  infoCard: {
    width: '47%',
    backgroundColor: '#f8fafc',
    padding: 16,
    borderRadius: 12,
  },
  infoCardTitle: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: '#6366f1',
    marginBottom: 8,
  },
  infoCardText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
});