import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Link } from 'expo-router';
import { GraduationCap, Calendar } from 'lucide-react-native';

export default function RegisterScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Join EventSnap</Text>
        <Text style={styles.subtitle}>Choose your registration type</Text>
      </View>

      <View style={styles.options}>
        <Link href="/register/student" asChild>
          <TouchableOpacity style={styles.option}>
            <View style={styles.optionIcon}>
              <GraduationCap size={32} color="#6366f1" />
            </View>
            <Text style={styles.optionTitle}>Register as Student</Text>
            <Text style={styles.optionDescription}>
              Join events, track your participation, and earn certificates
            </Text>
          </TouchableOpacity>
        </Link>

        <Link href="/register/organizer" asChild>
          <TouchableOpacity style={styles.option}>
            <View style={styles.optionIcon}>
              <Calendar size={32} color="#6366f1" />
            </View>
            <Text style={styles.optionTitle}>Register as Event Organizer</Text>
            <Text style={styles.optionDescription}>
              Create and manage events for your college community
            </Text>
          </TouchableOpacity>
        </Link>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>Already have an account?</Text>
        <TouchableOpacity>
          <Text style={styles.footerLink}>Login here</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 32,
    fontFamily: 'Inter_700Bold',
    color: '#111827',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 18,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  options: {
    flex: 1,
    padding: 20,
    gap: 20,
  },
  option: {
    backgroundColor: '#f8fafc',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#e5e7eb',
  },
  optionIcon: {
    width: 64,
    height: 64,
    backgroundColor: '#ede9fe',
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  optionTitle: {
    fontSize: 20,
    fontFamily: 'Inter_600SemiBold',
    color: '#111827',
    marginBottom: 8,
    textAlign: 'center',
  },
  optionDescription: {
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
    textAlign: 'center',
  },
  footer: {
    padding: 20,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  footerText: {
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
    color: '#6b7280',
  },
  footerLink: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: '#6366f1',
  },
});