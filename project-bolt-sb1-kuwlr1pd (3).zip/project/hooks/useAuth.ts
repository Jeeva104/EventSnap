import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Tables } from '@/lib/supabase';

export type UserType = 'student' | 'organizer';

interface AuthState {
  user: Tables['students']['Row'] | Tables['organizers']['Row'] | null;
  userType: UserType | null;
  loading: boolean;
}

export function useAuth() {
  const [state, setState] = useState<AuthState>({
    user: null,
    userType: null,
    loading: true,
  });

  useEffect(() => {
    // Check current auth state
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        checkUserType(session.user.id);
      } else {
        setState({ user: null, userType: null, loading: false });
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        checkUserType(session.user.id);
      } else {
        setState({ user: null, userType: null, loading: false });
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const checkUserType = async (userId: string) => {
    // Check if user is a student
    const { data: student } = await supabase
      .from('students')
      .select('*')
      .eq('id', userId)
      .single();

    if (student) {
      setState({ user: student, userType: 'student', loading: false });
      return;
    }

    // Check if user is an organizer
    const { data: organizer } = await supabase
      .from('organizers')
      .select('*')
      .eq('id', userId)
      .single();

    if (organizer) {
      setState({ user: organizer, userType: 'organizer', loading: false });
      return;
    }

    setState({ user: null, userType: null, loading: false });
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { error };
  };

  const signUp = async (
    email: string,
    password: string,
    userType: UserType,
    userData: Omit<Tables['students']['Insert'] | Tables['organizers']['Insert'], 'id' | 'email' | 'created_at'>
  ) => {
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    });

    if (authError || !authData.user) {
      return { error: authError };
    }

    const { error: profileError } = await supabase
      .from(userType === 'student' ? 'students' : 'organizers')
      .insert({
        id: authData.user.id,
        email,
        ...userData,
      });

    return { error: profileError };
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    return { error };
  };

  return {
    user: state.user,
    userType: state.userType,
    loading: state.loading,
    signIn,
    signUp,
    signOut,
  };
}