import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './useAuth';
import type { Tables } from '@/lib/supabase';

interface ProfileStats {
  eventsAttended: number;
  certificatesCount: number;
  upcomingEvents: number;
}

export function useProfile() {
  const { user, userType } = useAuth();
  const [stats, setStats] = useState<ProfileStats>({
    eventsAttended: 0,
    certificatesCount: 0,
    upcomingEvents: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.id) return;

    const fetchStats = async () => {
      setLoading(true);
      try {
        if (userType === 'student') {
          // Get attended events count
          const { count: attendedCount } = await supabase
            .from('event_registrations')
            .select('*', { count: 'exact' })
            .eq('student_id', user.id)
            .eq('status', 'attended');

          // Get upcoming events count
          const { count: upcomingCount } = await supabase
            .from('event_registrations')
            .select('*', { count: 'exact' })
            .eq('student_id', user.id)
            .eq('status', 'registered');

          setStats({
            eventsAttended: attendedCount || 0,
            certificatesCount: attendedCount || 0, // Assuming one certificate per attended event
            upcomingEvents: upcomingCount || 0,
          });
        } else {
          // For organizers
          const { count: totalEvents } = await supabase
            .from('events')
            .select('*', { count: 'exact' })
            .eq('organizer_id', user.id)
            .eq('status', 'completed');

          const { count: upcomingCount } = await supabase
            .from('events')
            .select('*', { count: 'exact' })
            .eq('organizer_id', user.id)
            .in('status', ['upcoming', 'active']);

          setStats({
            eventsAttended: totalEvents || 0,
            certificatesCount: 0, // Organizers don't receive certificates
            upcomingEvents: upcomingCount || 0,
          });
        }
      } catch (error) {
        console.error('Error fetching profile stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, [user?.id, userType]);

  return { stats, loading };
}