const { getDefaultConfig } = require('expo/metro-config');
const config = getDefaultConfig(__dirname);

// Optimize caching and reduce memory usage
config.cacheStores = [];
config.maxWorkers = 2;
config.transformer.minifierConfig = {
  compress: false,
  mangle: false
};

module.exports = config;