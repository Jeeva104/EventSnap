/*
  # Authentication and User Tables

  1. New Tables
    - `students`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `full_name` (text)
      - `college_name` (text)
      - `year_of_study` (integer)
      - `mobile_number` (text)
      - `created_at` (timestamp)

    - `organizers`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `full_name` (text)
      - `college_name` (text)
      - `department` (text)
      - `mobile_number` (text)
      - `event_types` (text)
      - `created_at` (timestamp)

    - `events`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `date` (timestamp)
      - `location` (text)
      - `district` (text)
      - `max_participants` (integer)
      - `registration_fee` (numeric)
      - `organizer_id` (uuid, foreign key)
      - `status` (text)
      - `created_at` (timestamp)

    - `event_registrations`
      - `id` (uuid, primary key)
      - `event_id` (uuid, foreign key)
      - `student_id` (uuid, foreign key)
      - `registration_date` (timestamp)
      - `status` (text)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated access
*/

-- Create students table
CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  college_name text NOT NULL,
  year_of_study integer NOT NULL,
  mobile_number text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE students ENABLE ROW LEVEL SECURITY;

-- Create organizers table
CREATE TABLE IF NOT EXISTS organizers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  college_name text NOT NULL,
  department text NOT NULL,
  mobile_number text NOT NULL,
  event_types text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE organizers ENABLE ROW LEVEL SECURITY;

-- Create events table
CREATE TABLE IF NOT EXISTS events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  date timestamptz NOT NULL,
  location text NOT NULL,
  district text NOT NULL,
  max_participants integer,
  registration_fee numeric DEFAULT 0,
  organizer_id uuid REFERENCES organizers(id) NOT NULL,
  status text NOT NULL DEFAULT 'upcoming',
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('upcoming', 'active', 'completed', 'cancelled'))
);

ALTER TABLE events ENABLE ROW LEVEL SECURITY;

-- Create event registrations table
CREATE TABLE IF NOT EXISTS event_registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) NOT NULL,
  student_id uuid REFERENCES students(id) NOT NULL,
  registration_date timestamptz DEFAULT now(),
  status text NOT NULL DEFAULT 'registered',
  CONSTRAINT valid_registration_status CHECK (status IN ('registered', 'attended', 'cancelled')),
  CONSTRAINT unique_registration UNIQUE(event_id, student_id)
);

ALTER TABLE event_registrations ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Students policies
CREATE POLICY "Students can read own data"
  ON students
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = id::text);

CREATE POLICY "Students can update own data"
  ON students
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = id::text);

-- Organizers policies
CREATE POLICY "Organizers can read own data"
  ON organizers
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = id::text);

CREATE POLICY "Organizers can update own data"
  ON organizers
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = id::text);

-- Events policies
CREATE POLICY "Events are viewable by everyone"
  ON events
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Organizers can create events"
  ON events
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = organizer_id::text);

CREATE POLICY "Organizers can update own events"
  ON events
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = organizer_id::text);

-- Event registrations policies
CREATE POLICY "Students can view own registrations"
  ON event_registrations
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = student_id::text);

CREATE POLICY "Students can register for events"
  ON event_registrations
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = student_id::text);

CREATE POLICY "Students can cancel own registrations"
  ON event_registrations
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = student_id::text);