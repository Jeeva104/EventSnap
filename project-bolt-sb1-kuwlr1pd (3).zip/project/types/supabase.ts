export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      students: {
        Row: {
          id: string
          email: string
          full_name: string
          college_name: string
          year_of_study: number
          mobile_number: string
          created_at: string
        }
        Insert: {
          id?: string
          email: string
          full_name: string
          college_name: string
          year_of_study: number
          mobile_number: string
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          college_name?: string
          year_of_study?: number
          mobile_number?: string
          created_at?: string
        }
      }
      organizers: {
        Row: {
          id: string
          email: string
          full_name: string
          college_name: string
          department: string
          mobile_number: string
          event_types: string | null
          created_at: string
        }
        Insert: {
          id?: string
          email: string
          full_name: string
          college_name: string
          department: string
          mobile_number: string
          event_types?: string
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          college_name?: string
          department?: string
          mobile_number?: string
          event_types?: string
          created_at?: string
        }
      }
      events: {
        Row: {
          id: string
          title: string
          description: string | null
          date: string
          location: string
          district: string
          max_participants: number | null
          registration_fee: number
          organizer_id: string
          status: string
          created_at: string
        }
        Insert: {
          id?: string
          title: string
          description?: string
          date: string
          location: string
          district: string
          max_participants?: number
          registration_fee?: number
          organizer_id: string
          status?: string
          created_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string
          date?: string
          location?: string
          district?: string
          max_participants?: number
          registration_fee?: number
          organizer_id?: string
          status?: string
          created_at?: string
        }
      }
      event_registrations: {
        Row: {
          id: string
          event_id: string
          student_id: string
          registration_date: string
          status: string
        }
        Insert: {
          id?: string
          event_id: string
          student_id: string
          registration_date?: string
          status?: string
        }
        Update: {
          id?: string
          event_id?: string
          student_id?: string
          registration_date?: string
          status?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}